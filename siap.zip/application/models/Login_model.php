<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();

    }

    public function validar($usercifo,$passwordcifo)
    {
        $this->db->where('usuario',$usercifo);
        $this->db->where('pwd',$passwordcifo);
        $query = $this->db->get('cat_usuarios');
        if($query->num_rows() == 1)
        {
            return $query->row();
        }
        else
        {

        }
    }

    public function bloquear($usercifo,$data1)
    {
        $this->db->where('usuario',$usercifo);
        $this->db->update('cat_usuarios', $data1);
        if($this->db->affected_rows() > 0)
        {
            return TRUE;
        }
        else
        {
            RETURN FALSE;
        }

    }
}