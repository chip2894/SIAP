<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('email','','correo');
        $this->load->helper('url');
        $this->load->database('default');
    }

	public function index()
	{
		$this->load->view('Login');
	}

	public function validar()
    {
        if(isset($_POST['usuariocifo']) && isset($_POST['passwordcifo']))
        {
            $formrules = array(
                array(
                    'field' => 'usuariocifo',
                    'label' => 'Usuario',
                    'rules' => 'required|alpha'
                ),
                array(
                    'field' => 'passwordcifo',
                    'label' => 'Paswword',
                    'rules' => 'required'
                )
            );
            $this->form_validation->set_rules($formrules);
            if($this->form_validation->run() == TRUE)
            {
                $usercifo=$_POST['usuariocifo'];
                $passwordcifo=$_POST['passwordcifo'];
                    $validar = $this->login_model->validar($usercifo,$passwordcifo);
                    if($validar == TRUE)
                    {
                        $data = array (
                            'id_usuario' => $validar->id_usuario,
                            'usuario' => $validar->usuario,
                            'estatus' => $validar->estatus,
                            'logueado' => TRUE
                        );
                        if($data['estatus']==1)
                        {
                            echo $data['id_usuario']."<br>";
                            echo $data['usuario']."<br>";
                            echo $data['estatus'];
                            $this->session->set_userdata('SIAP-CIFO',$data);
                            redirect('Welcome/logueado');
                        }
                        else
                        {
                            $datos['aviso'] ='EL USUARIO ESTA DESACTIVADO, CONSULTE AL ADMINISTRADOR';
                            $this->load->view('Login',$datos);
                        }
                    }
                    else
                    {
                        $datos['aviso'] ='USUARIO O CAONTRASEÑA INCORRECTOS';
                        $this->load->view('Login',$datos);
                    }
            }
            else
            {
                $this->load->view('Login');
            }
        }
        else
        {
            $this->load->view('Login');
        }
    }

    public function logueado()
    {
        if($this->session->userdata('SIAP-CIFO'))
        {
            $data = array();
            $data[] = $this->session->userdata('SIAP-CIFO');
            $html="";
            $html.='<script>
                var url="'.base_url().'index.php/";
                window.location.replace(url+"InicioSiap/index");
            </script>';
            echo $html;
        }
        else
        {
            redirect('/Login','refresh');
        }
    }
}
