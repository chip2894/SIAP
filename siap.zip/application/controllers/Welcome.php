<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('url','form'));
    }

	public function index()
	{
		$this->load->view('Login');
	}

	public function validar()
    {
        if(isset($_POST['usuariocifo']) && isset($_POST['passwordcifo']))
        {
            $formrules = array(
                array(
                    'field' => 'usuariocifo',
                    'label' => 'Usuario',
                    'rules' => 'required|alpha'
                ),
                array(
                    'field' => 'passwordcifo',
                    'label' => 'Paswword',
                    'rules' => 'required'
                )
            );
            $this->form_validation->set_rules($formrules);
            if($this->form_validation->run() == TRUE)
            {
                if($_POST['bandera']<3)
                {

                }
                else
                {
                    $datos['aviso'] ='SE A SUPERADO EL NUMERO DE INTENTOS, USUARIO BLOQUEADO, POR FAVOR CONSULTA A TU ADMINISTRADOR';
                    $this->load->view('login',$datos);
                }
            }
            else
            {
                $this->load->view('login');
            }
        }
        else
        {
            $this->load->view('Login');
        }
    }
}
